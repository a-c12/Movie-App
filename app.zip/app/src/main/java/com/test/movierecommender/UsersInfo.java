package com.test.movierecommender;

import com.google.firebase.database.IgnoreExtraProperties;
import com.google.firebase.database.PropertyName;

// this is a model class for setting and getting values of user info
@IgnoreExtraProperties
public class UsersInfo {
    private String _id;

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    private String _name;
    private String _email;
    private String _age;
    private String _password;

    public String get_name() {
        return _name;
    }

    public void set_name(String _name) {
        this._name = _name;
    }

    public String get_email() {
        return _email;
    }

    public void set_email(String _email) {
        this._email = _email;
    }

    public String get_age() {
        return _age;
    }

    public void set_age(String _age) {
        this._age = _age;
    }

    public String get_password() {
        return _password;
    }

    public void set_password(String _password) {
        this._password = _password;
    }


    //constructor for user info class
    public UsersInfo(String _id,String _name, String _email, String _age, String _password) {
        this._id = _id;
        this._name = _name;
        this._email = _email;
        this._age = _age;
        this._password = _password;
    }
    public UsersInfo() {

    }

}

