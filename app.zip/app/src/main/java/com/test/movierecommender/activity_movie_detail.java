package com.test.movierecommender;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;


public class activity_movie_detail extends AppCompatActivity {

    ImageView cover_image;
    TextView txt_title, txt_rating, txt_overview;
    Button btn_trailer;
    String movie_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);
        this.setTitle("Movie Detail");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        btn_trailer = findViewById(R.id.btn_trailer);
        cover_image = findViewById(R.id.movie_img);
        txt_title = findViewById(R.id.txt_title);
        txt_rating = findViewById(R.id.txt_rating);
        txt_overview = findViewById(R.id.txt_overview);
        // below we are getting extra data from previous activity and showing it on respective views
        movie_id = getIntent().getExtras().getString("movie_id", "defaultKey");
        txt_title.setText(getIntent().getExtras().getString("title", "defaultKey"));
        txt_rating.setText(getIntent().getExtras().getString("rating", "defaultKey"));
        txt_overview.setText(getIntent().getExtras().getString("overview", "defaultKey"));
        Picasso.get().load(getIntent().getExtras().getString("cover", "defaultKey")).into(cover_image);
        btn_trailer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // here when button click for watch trailor what we are doing is we are making again api call and now this timw we ae passing id of the movie to api server to receive key of video for youtube .
                new GetAsynTask().execute("https://api.themoviedb.org/3/movie/" + movie_id + "/videos?api_key=bebd234732e6ddad177e1b47cd4ade83");

            }
        });
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
    public class GetAsynTask extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Helper.showLoader(activity_movie_detail.this, "Please Wait . . . ");
        }

        @Override
        protected String doInBackground(String... params) {

            try {
                String s = params[0];

                return Helper.getDataFromUrl(params[0]);

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String resultData) {
            super.onPostExecute(resultData);
            // got response from server api after request
            Log.i("Dumper", resultData);
            try {
                Helper.stopLoader();

                try {
                    // parsing reponse using json object
                    JSONObject obj = new JSONObject(resultData);
                    JSONArray array = obj.getJSONArray("results");


                    JSONObject objx = array.getJSONObject(0);
                   ;
                    Intent intent = new Intent(activity_movie_detail.this, activity_trailer.class);
                    // got key value for trailor of movie and passed to next trailor screen
                    intent.putExtra("key", objx.getString("key"));
                    startActivity(intent);
                } catch (Exception e) {
                    Log.i("Error", e.getMessage());
                    Toast.makeText(activity_movie_detail.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                }


            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(activity_movie_detail.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }


        }
    }
}