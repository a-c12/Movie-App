package com.test.movierecommender;


import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class activity_register extends AppCompatActivity {
    Button btn_signup;

    TextInputLayout fullname,email,age,password;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    UsersInfo usersInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        this.setTitle("Movie Recommender Registration");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        // get instance of firebase database
        firebaseDatabase = FirebaseDatabase.getInstance();
        // get reference  of particular location from firebase database
        databaseReference = firebaseDatabase.getReference("Users");
        usersInfo=new UsersInfo();
        fullname = (TextInputLayout) findViewById(R.id.txt_fname);
        email = (TextInputLayout) findViewById(R.id.txt_email);
        age = (TextInputLayout) findViewById(R.id.txt_age);
        password = (TextInputLayout) findViewById(R.id.txt_password);
        btn_signup=findViewById(R.id.btn_signup);

        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                registerNewUser();
            }
        });
    }

    private void registerNewUser()
    {
        String _fname,_age,_email, _password;
        _fname = fullname.getEditText().getText().toString();
        _email = email.getEditText().getText().toString();
        _age = age.getEditText().getText().toString();
        _password = password.getEditText().getText().toString();


        if (TextUtils.isEmpty(_fname)) {
            Toast.makeText(getApplicationContext(), "Please enter FullName!!", Toast.LENGTH_LONG).show();

            return;
        }
        if (TextUtils.isEmpty(_email)) {
            Toast.makeText(getApplicationContext(), "Please enter email!!", Toast.LENGTH_LONG).show();

            return;
        }

        if (TextUtils.isEmpty(_age)) {
            Toast.makeText(getApplicationContext(), "Please enter Age!!", Toast.LENGTH_LONG).show();
            return;
        }
        if (TextUtils.isEmpty(_password)) {
            Toast.makeText(getApplicationContext(), "Please enter password!!", Toast.LENGTH_LONG).show();
            return;
        }
      if(_password.length()<=3){
          Toast.makeText(getApplicationContext(), "Please length must be above 3 letters", Toast.LENGTH_LONG).show();
          return;
      }

      else{
        Helper.showLoader(activity_register.this,"Please wait . . .");
          String id = databaseReference.push().getKey();
          UsersInfo usersInfo = new UsersInfo(id, _fname,_email,_age,_password);
          // register a event listner for database change on firebase side . when data change change ondatachange event called
          databaseReference.addValueEventListener(new ValueEventListener() {
              @Override
              public void onDataChange(@NonNull DataSnapshot snapshot) {

                  databaseReference.child(id).setValue(usersInfo);
                  Helper.stopLoader();
                  Toast.makeText(activity_register.this, "Account Created Successfully!", Toast.LENGTH_SHORT).show();
              }

              @Override
              public void onCancelled(@NonNull DatabaseError error) {
                  Helper.stopLoader();
                  Toast.makeText(activity_register.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
              }
          });


      }
      }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
