package com.test.movierecommender;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;


public class movies_viewholder extends RecyclerView.Adapter<movies_viewholder.class_movies>{

    Context context;

    ArrayList<Movies> _movies;  // array list for movies data

    // parametertized constructor for viewholder class
    public movies_viewholder(Context c , ArrayList<Movies> _mov)
    {
        context = c;
        _movies = _mov;

    }


    //This method is called right when the adapter is created and is used to initialize your ViewHolder(s).
    @NonNull
    @Override
    public class_movies onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new class_movies(LayoutInflater.from(context).inflate(R.layout.card_layout_movies,parent, false));
    }


// below method display the data at the specified position. This method is used to update the contents of the itemView to reflect the item at the given position.
    @Override
    public void onBindViewHolder(@NonNull final class_movies holder, @SuppressLint("RecyclerView") final int position) {
        holder.name.setText(_movies.get(position).getName());
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // here when we click on a specific movie card we are passing that info to next detail screen
                Intent intent = new Intent(context, activity_movie_detail.class);
                intent.putExtra("movie_id",_movies.get(position).getId());
                intent.putExtra("title", _movies.get(position).getName());
                intent.putExtra("cover", "https://image.tmdb.org/t/p/w500"+_movies.get(position).getCover());
                intent.putExtra("rating", _movies.get(position).getRating());
                intent.putExtra("overview", _movies.get(position).getOverview());
                context.startActivity(intent);
            }
        });

       Picasso.get().load("https://image.tmdb.org/t/p/w500"+_movies.get(position).getCover()).into(holder.movie_cover);


    }

    @Override
    public int getItemCount() {
        return _movies.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }





    class class_movies extends RecyclerView.ViewHolder{
        TextView name;
        ImageView movie_cover,isFav;
        CardView cardView;

        public class_movies(View itemView){
            super(itemView);
            movie_cover  = (ImageView) itemView.findViewById(R.id.movie_cover);
            name  = (TextView) itemView.findViewById(R.id.movie_name);
            cardView = (CardView)itemView.findViewById(R.id.cardview);
        }
    }
}
