package com.test.movierecommender;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class activity_dashboard extends AppCompatActivity {
    boolean doubleBackToExitPressedOnce = false;
    // created a array of category
    String[] movie_category = { "Adventure", "Animation", "Comedy", "Drama", "Family","Fantsy","History","Horror","Thriller"};
    // created a array of codes according to category
    String[] category_code = {  "12", "16", "35","18","10751","14","36","27","53"};

    String[] movie_year = {  "2000", "2001", "2002","2003","2004","2005","2006","2007","2008","2009","2010","2011","2012","2013","2013","2014","2015","2016","2017","2018","2019","2020"};
    int category_selected_position=0,year_selected_position=0;
    Button btn_get;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        this.setTitle("Select Genre and Year");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        // below initialise a dropdown for category to show all categries into a dropdown
        Spinner spin_category = (Spinner) findViewById(R.id.spinner_genre);

        spin_category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            category_selected_position=position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter aa_category = new ArrayAdapter(this,android.R.layout.simple_spinner_item,movie_category);
        aa_category.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin_category.setAdapter(aa_category);



        // below initializez a dropdown for years to show all years into a dropdown
        Spinner spin_year = (Spinner) findViewById(R.id.spinner_year);
        spin_year.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            year_selected_position=position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter aa_year = new ArrayAdapter(this,android.R.layout.simple_spinner_item,movie_year);
        aa_year.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin_year.setAdapter(aa_year);

        btn_get=findViewById(R.id.btn_get);
        btn_get.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               // here when presses get movies button we are passing category code and year to next activity where we are passing value to api url to get our required response


                Intent intent = new Intent(activity_dashboard.this, MainActivity.class);
                intent.putExtra("genre", movie_category[category_selected_position]);
                intent.putExtra("genrecode", category_code[category_selected_position]);
                intent.putExtra("year", movie_year[year_selected_position]);
                startActivity(intent);
            }
        });


    }
    @Override
    public boolean onSupportNavigateUp() {
       finish();
        return true;
    }
    @Override
    public void onBackPressed() {



            if (doubleBackToExitPressedOnce) {

                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        finish();
                    }
                }, 0);
                return;
            }

            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Please click back again to exit", Toast.LENGTH_SHORT).show();
            //  ad_loader();

            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    doubleBackToExitPressedOnce=false;
                }
            }, 2000);

        }
}