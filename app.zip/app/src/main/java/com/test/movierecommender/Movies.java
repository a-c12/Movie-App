package com.test.movierecommender;

// this is a model class for setting and getting values of movies data
public class Movies {
    String id,cover,name,rating,overview;

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }





    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public Movies() {
    }
    //constructor for user movies info class
    public Movies(String id, String name, String cover,String rating,String overview) {
        this.id = id;
        this.cover = cover;
        this.name = name;
        this.rating = rating;
        this.overview = overview;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
