package com.test.movierecommender;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity  {

    RecyclerView recyclerView;
    ArrayList<Movies> movies_list;
    movies_viewholder adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        movies_list=new ArrayList<>();
        recyclerView = (RecyclerView)findViewById(R.id.recyclerView); // initializing recyclerview
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));
        Bundle extras = getIntent().getExtras();
        if(extras != null) {
            this.setTitle(extras.getString("genre")+" : "+extras.getString("year") );
            // making a get call request to fetch data from api which are using . we are sending two things into url to get particular respose
            //in our case we need movies of specific category and year . so that why we have passed two paramaters in it .
            new GetAsynTask().execute("https://api.themoviedb.org/3/discover/movie?api_key=bebd234732e6ddad177e1b47cd4ade83&with_genres=" + extras.getString("genrecode")+"&year="+extras.getString("year"));

        }
    }

    // this below class is our background worker class . because all server request we deal on background thread so it won't affect our UI.
    public class GetAsynTask extends AsyncTask<String, String, String> {

        // below method exceute before starting background work
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Helper.showLoader(MainActivity.this,"Please Wait . . . ");
        }

        // below method exceute in background . here below we are making server request to get our required data.
        @Override
        protected String doInBackground(String... params) {

            try {
                String s = params[0];

                return Helper.getDataFromUrl(params[0]);

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        // when background work completes . we receive some sort of response according to our need
        @Override
        protected void onPostExecute(String resultData) {
            super.onPostExecute(resultData);

            Log.i("Dumper",resultData);
            // below code execute when we receice response from server in a json format then we are parcing that json with key values that are already defined in json
            try {
                Helper.stopLoader();
                movies_list.clear();
                try {

                    // we are using jsonobject for parsing our json data which is in from of string
                    JSONObject obj= new JSONObject(resultData);

                    // our received data is in form of array . so we are getting array with key value results .
                    JSONArray array=obj.getJSONArray("results");

                    // below is loop to iterate through all json array to get our required things with key
                    for (int index = 0; index < array.length(); index++) {

                        JSONObject objx = array.getJSONObject(index);
                        if(Double.parseDouble(objx.getString("vote_average"))>=7.0){
                            movies_list.add(new Movies(objx.getString("id"),objx.getString("title"),objx.getString("poster_path"),objx.getString("vote_average"),objx.getString("overview")));

                        }

                    }

                    // after parsing all data we saved all data into list . if list size is greater then zero then we are passing data to viewholder class to show all data in form of list

                    if (movies_list.size() > 0) {
                        adapter = new movies_viewholder(MainActivity.this, movies_list);
                        recyclerView.setAdapter(adapter);


                    } else {

                    }


                } catch (Exception e) {
                    Log.i("Error",e.getMessage());

                }



            } catch (Exception e) {
                e.printStackTrace();
            }


        }
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}