package com.test.movierecommender;

import android.os.Bundle;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class activity_login extends AppCompatActivity {


    TextInputLayout email,password;
    Button btn_signin, btn_register;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    ArrayList<UsersInfo> usersInfos=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        this.setTitle("Movie Recommender Login");
        // get instance of firebase database
        firebaseDatabase = FirebaseDatabase.getInstance();
        // get reference  of particular location from firebase database
        databaseReference = firebaseDatabase.getReference("Users");
        email = (TextInputLayout) findViewById(R.id.txt_email);
        password = (TextInputLayout) findViewById(R.id.txt_password);
        btn_signin = findViewById(R.id.btn_signin);
        btn_register = findViewById(R.id.btn_register);
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(activity_login.this,activity_register.class));
            }
        });


        btn_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Helper.isEmailValid((email.getEditText().getText().toString()))){
                    Helper.showLoader(activity_login.this,"Please wait . . .");

                    // register a event listner for database change on firebase side . when data change change ondatachange event called
                    ValueEventListener eventListener = new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            usersInfos.clear();
                            for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                UsersInfo artist = postSnapshot.getValue(UsersInfo.class);
                                usersInfos.add(artist);
                            }

                            if(usersInfos.size()>0){
                                for (int i=0; i<usersInfos.size(); i++) {

                                    if(usersInfos.get(i).get_email().equals(email.getEditText().getText().toString()) && usersInfos.get(i).get_password().equals(password.getEditText().getText().toString())){
                                        Helper.stopLoader();
                                        Toast.makeText(activity_login.this,"Login Successfull!",Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(activity_login.this,activity_dashboard.class));
                                        break;
                                    }
                                    else{
                                        Helper.stopLoader();
                                        Toast.makeText(activity_login.this,"Login UnSuccessfull!",Toast.LENGTH_LONG).show();

                                    }
                                }
                            }
                            else{
                                Helper.stopLoader();
                                Toast.makeText(activity_login.this,"Login UnSuccessfull!",Toast.LENGTH_LONG).show();

                            }



                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {}
                    };

                    databaseReference.addListenerForSingleValueEvent(eventListener);
                }
                else{
                    Toast.makeText(activity_login.this, "Email is invalid", Toast.LENGTH_SHORT).show();
                }



            }
        });
    }

}
