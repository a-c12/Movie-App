package com.test.movierecommender;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ValidationTest {

    Helper helper;
    activity_login activity_login;
    @Before
    public void setUp() {
        helper=new Helper();
        activity_login=new activity_login();
    }
    @Test
    public  void check_email(){
        String email="test@gmail.com";
        assertTrue(helper.isEmailValid(email));
    }





}
